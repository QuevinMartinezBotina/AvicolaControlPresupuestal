<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <div class="row mx-md-5 mb-5 shadow border rounded my-5">
        <div class="col-md-4 ">
            <img src="../../../../img/proveedores.svg" class="img-fluid p-2" alt="">
        </div>

        <div class="col-md-8 p-3 text-center align-self-center ">
            <h1>Bienvenido al modulo de Proveedores</h1>
        </div>
    </div>

</body>

</html>