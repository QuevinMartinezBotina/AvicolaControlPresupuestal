<?php

$servidor="localhost";
$usuario="root";
$pass="";
$bd="controlpresupuestal";

$conexion= mysqli_connect($servidor, $usuario, $pass, $bd);

